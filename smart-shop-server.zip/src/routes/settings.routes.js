const router = require("express").Router();

const auth = require("../middlewares/auth");
const requireRole = require("../middlewares/requireRole");

const c = require("../controllers/settings.controller");

// ✅ PUBLIC (storefront-safe)
router.get("/public", c.getPublicSettings);

// ✅ Admin settings (RBAC)
const canManageSettings = requireRole({ anyPermissions: ["settings:write"] });

router.get("/admin", auth, canManageSettings, c.getAdminSettings);
router.put("/admin", auth, canManageSettings, c.upsertAdminSettings);
router.post("/admin/reset", auth, canManageSettings, c.resetAdminSettings);

module.exports = router;
