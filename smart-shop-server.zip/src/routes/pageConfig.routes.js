const router = require("express").Router();

const c = require("../controllers/pageConfig.controller");
const auth = require("../middlewares/auth");
const requireRole = require("../middlewares/requireRole");

// Public
router.get("/shop", c.getShopPublic);

// ✅ NEW: Public admin settings (safe subset)
router.get("/admin-settings/public", c.getAdminSettingsPublic);

// Admin
router.put("/shop", auth, requireRole("admin"), c.upsertShop);

// ✅ NEW: Admin settings (full doc)
router.get(
  "/admin-settings",
  auth,
  requireRole({ mode: "any", minLevel: 100, anyPermissions: ["settings:write"] }, "admin"),
  c.getAdminSettings
);

router.put(
  "/admin-settings",
  auth,
  requireRole({ mode: "any", minLevel: 100, anyPermissions: ["settings:write"] }, "admin"),
  c.upsertAdminSettings
);

module.exports = router;
